package org.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cts.claims.dao.AdjusterDaoImpl;
import org.cts.claims.dao.ClaimDaoImpl;

import com.google.gson.Gson;

/**
 * Servlet implementation class SearchAdjusterController
 */
@WebServlet("/SearchAdjuster")
public class SearchAdjusterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    AdjusterDaoImpl dao=new AdjusterDaoImpl();
    //ClaimDaoImpl claimdao=new ClaimDaoImpl();
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Integer> list=new ArrayList<>();
		PrintWriter pw=response.getWriter();
		response.setContentType("application/json");
	    response.setCharacterEncoding("UTF-8");
		try {
			String claim_type = request.getParameter("id2");
            int exp=Integer.parseInt(request.getParameter("id"));
            
			list=dao.search(exp,claim_type);
			 String json = new Gson().toJson(list);
			    pw.write(json);
			    pw.flush();
		}
 		catch (Exception e) {
	            e.printStackTrace();
	        }
	
	}

}
