package org.cts.controller;



import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.cts.claims.dao.AuthenticationDaoImpl;
import org.cts.claims.model.Authentication;





@WebServlet("/validateUser")

public class ValidateUserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	AuthenticationDaoImpl dao=new AuthenticationDaoImpl();
	String msg="";
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String uname=request.getParameter("id");
		//String pid=request.getParameter("id")
		System.out.println(uname);
		Authentication p=dao.getAuthentication(uname);
		if(p!=null)
		{
			msg=msg+"User already exists";
		}
		pw.write(msg);
		msg="";
		pw.close();

	}



}