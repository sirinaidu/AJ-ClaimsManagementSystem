package org.cts.controller;



import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cts.claims.dao.ClaimDaoImpl;
import org.cts.claims.dao.PolicyDaoImpl;
import org.cts.claims.model.Claim;


@WebServlet("/validateClaimId")

public class ValidateClaimIdController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ClaimDaoImpl dao=new ClaimDaoImpl();
	String msg="";
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		int pid=Integer.parseInt(request.getParameter("id"));
		//String pid=request.getParameter("id")
		//System.out.println(pid);
		Claim p=dao.getClaim(pid);
		if(p==null)
		{
			msg=msg+"Claim does not exists";
		}
		pw.write(msg);
		msg="";
		pw.close();

	}



}