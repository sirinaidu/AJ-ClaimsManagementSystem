
package org.cts.controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/search1")
public class SearchCSRController extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        Connection conn = null;
        String url = "jdbc:mysql://localhost:3306/";
        String dbName = "ctsdb";
        String driver = "com.mysql.jdbc.Driver";
        String userName = "root";
        String password = "root";
        Statement st=null;
        try {
            Class.forName(driver).newInstance();
            conn = DriverManager.getConnection(url + dbName, userName, password);
            System.out.println("connected!.....");
            String id = request.getParameter("id");
            String custid = request.getParameter("custid");
            String adjid = request.getParameter("adjid");
            System.out.println("query " + custid);
            String query = null;
            if(id!=null && adjid!=null && custid!=null && id!="" && adjid!="" && custid!="") {
                ArrayList al = null;
                ArrayList pid_list = new ArrayList();
                
              
                    query = "select * from claims where id='" + id + "' and adjuster_id='" + adjid + "'  and customer_id='" + custid + "' ";
               
                System.out.println("query " + query);
                st = conn.createStatement();
                ResultSet rs = st.executeQuery(query);

                while (rs.next()) {
                    al = new ArrayList();

                    al.add(rs.getString(1));
                    al.add(rs.getString(2));
                    al.add(rs.getString(3));
                    al.add(rs.getString(4));
                    al.add(rs.getString(5));
                    System.out.println("al :: " + al);
                    pid_list.add(al);
                }

                request.setAttribute("piList", pid_list);
                RequestDispatcher searchClaim = request.getRequestDispatcher("SearchClaim.jsp");
                searchClaim.forward(request, response);
                conn.close();
                System.out.println("Disconnected!");
                } 
            
            
            else   if(id!=null && adjid!=null && id!="" && adjid!=""   ) {
                ArrayList al = null;
                ArrayList pid_list = new ArrayList();
                
              
                    query = "select * from claims where id='" + id + "' and adjuster_id='" + adjid + "' ";
              
                System.out.println("query " + query);
                st = conn.createStatement();
                ResultSet rs = st.executeQuery(query);

                while (rs.next()) {
                    al = new ArrayList();

                    al.add(rs.getString(1));
                    al.add(rs.getString(2));
                    al.add(rs.getString(3));
                    al.add(rs.getString(4));
                    al.add(rs.getString(5));
                    System.out.println("al :: " + al);
                    pid_list.add(al);
                }

                request.setAttribute("piList", pid_list);
                RequestDispatcher searchClaim = request.getRequestDispatcher("SearchClaim.jsp");
                searchClaim.forward(request, response);
                conn.close();
                System.out.println("Disconnected!");
                }
            
            else if(id!=null && custid!=null && id!=""  && custid!="") {
                ArrayList al = null;
                ArrayList pid_list = new ArrayList();
               
              
                    query = "select * from claims where id='" + id + "' and customer_id='" + custid + "'";
               
                System.out.println("query " + query);
                st = conn.createStatement();
                ResultSet rs = st.executeQuery(query);

                while (rs.next()) {
                    al = new ArrayList();

                    al.add(rs.getString(1));
                    al.add(rs.getString(2));
                    al.add(rs.getString(3));
                    al.add(rs.getString(4));
                    al.add(rs.getString(5));
                    System.out.println("al :: " + al);
                    pid_list.add(al);
                }

                request.setAttribute("piList", pid_list);
                RequestDispatcher searchClaim = request.getRequestDispatcher("SearchClaim.jsp");
                searchClaim.forward(request, response);
                conn.close();
                System.out.println("Disconnected!");
                }
            
            else   if(id==""  && adjid!="" && custid!="") {
                ArrayList al = null;
                ArrayList pid_list = new ArrayList();
               
                    query = "select * from claims where customer_id='" + custid + "' and adjuster_id='" + adjid + "'";
              
                System.out.println("query " + query);
                st = conn.createStatement();
                ResultSet rs = st.executeQuery(query);

                while (rs.next()) {
                    al = new ArrayList();

                    al.add(rs.getString(1));
                    al.add(rs.getString(2));
                    al.add(rs.getString(3));
                    al.add(rs.getString(4));
                    al.add(rs.getString(5));
                    System.out.println("al :: " + al);
                    pid_list.add(al);
                }

                request.setAttribute("piList", pid_list);
                RequestDispatcher searchClaim = request.getRequestDispatcher("SearchClaim.jsp");
                searchClaim.forward(request, response);
                conn.close();
                System.out.println("Disconnected!");
                }
            else   
            if(id!=null &&  id!="" && custid=="" && adjid==""   ) {
                ArrayList al = null;
                ArrayList pid_list = new ArrayList();
               
               
                    query = "select * from claims where id='" + id + "' ";
              
                System.out.println("query " + query);
                st = conn.createStatement();
                ResultSet rs = st.executeQuery(query);

                while (rs.next()) {
                    al = new ArrayList();

                    al.add(rs.getString(1));
                    al.add(rs.getString(2));
                    al.add(rs.getString(3));
                    al.add(rs.getString(4));
                    al.add(rs.getString(5));
                    System.out.println("al :: " + al);
                    pid_list.add(al);
                }

                request.setAttribute("piList", pid_list);
                RequestDispatcher searchClaim = request.getRequestDispatcher("SearchClaim.jsp");
                searchClaim.forward(request, response);
                conn.close();
                System.out.println("Disconnected!");
                }
                
              
                
            else if(adjid!=null&& adjid!="" && id!="" && custid=="" ) {
                    ArrayList al = null;
                    ArrayList pid_list = new ArrayList();
                   
                        query = "select * from claims where adjuster_id='" + adjid + "' ";
                
                    System.out.println("query " + query);
                    st = conn.createStatement();
                    ResultSet rs = st.executeQuery(query);

                    while (rs.next()) {
                        al = new ArrayList();

                        al.add(rs.getString(1));
                        al.add(rs.getString(2));
                        al.add(rs.getString(3));
                        al.add(rs.getString(4));
                        al.add(rs.getString(5));
                        System.out.println("al :: " + al);
                        pid_list.add(al);
                    }

                    request.setAttribute("piList", pid_list);
                    RequestDispatcher searchClaim = request.getRequestDispatcher("SearchClaim.jsp");
                    searchClaim.forward(request, response);
                    conn.close();
                    System.out.println("Disconnected!");
                    }
                
            else if(custid!=""&& id=="" && adjid=="") {
                    ArrayList al = null;
                    ArrayList pid_list = new ArrayList();
                  
                        query = "select * from claims where customer_id='" + custid + "' ";
                    
                    System.out.println("query " + query);
                    st = conn.createStatement();
                    ResultSet rs = st.executeQuery(query);

                    while (rs.next()) {
                        al = new ArrayList();

                        al.add(rs.getString(1));
                        al.add(rs.getString(2));
                        al.add(rs.getString(3));
                        al.add(rs.getString(4));
                        al.add(rs.getString(5));
                        System.out.println("al :: " + al);
                        pid_list.add(al);
                    }

                    request.setAttribute("piList", pid_list);
                    RequestDispatcher searchClaim = request.getRequestDispatcher("SearchClaim.jsp");
                    searchClaim.forward(request, response);
                    conn.close();
                    System.out.println("Disconnected!");
                    }
                
            else if(custid==""  && adjid=="" && id=="") {
            	response.setContentType("text/html");
        		PrintWriter pw=response.getWriter();
            	pw.println("<script type=\"text/javascript\">");
    			pw.println("alert('Enter atleast any one value');");
    			pw.println("</script>");
    			RequestDispatcher rd=request.getRequestDispatcher("csr.jsp");
    			rd.include(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}