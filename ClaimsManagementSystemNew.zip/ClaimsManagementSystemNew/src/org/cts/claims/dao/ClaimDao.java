package org.cts.claims.dao;

import java.util.List;

import org.cts.claims.model.*;

public interface  ClaimDao {
  
     	String insertAutoClaim( Claim a);
     	String insertPropertyClaim( Claim a);
		Claim getClaim (int pid);
		//List<Claim> getClaims();
		List<Claim> search(String name);
		String insert(int id,int cid,double am1,double am2,Claim claim);	
	}
